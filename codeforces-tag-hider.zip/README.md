# hide-question-tag
Hide tags of questions on codeforces while practicing.
